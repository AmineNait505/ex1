package com.example.examen.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.examen.R;

public class MainActivity extends AppCompatActivity {
    public EditText edtxt;
    public Button converetir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    public void init(){
        edtxt=findViewById(R.id.second);
        converetir=findViewById(R.id.convertir);
        converetir.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String inputseconds=edtxt.getText().toString();
                if (!inputseconds.isEmpty()){
                    Intent intent=new Intent(MainActivity.this,ResultActivity.class);
                    intent.putExtra("SECONDSTOCONVERT",inputseconds);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(MainActivity.this,"please enter a valid number",Toast.LENGTH_LONG).show();
                }
            }

        });
    }
}