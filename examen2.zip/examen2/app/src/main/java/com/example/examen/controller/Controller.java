package com.example.examen.controller;

import com.example.examen.model.TimeConvertir;

import java.util.concurrent.TimeUnit;

public class Controller {
    private static Controller instance;
    private TimeConvertir timeConvertir;
    public static Controller getInstance(){
        if (instance==null){instance=new Controller();}
        return instance;
    }
    public void createTimeConversion(int seconds){
        timeConvertir= new TimeConvertir(seconds);
    }
    public String getTemps(){
        long hours= TimeUnit.SECONDS.toHours(timeConvertir.getSeconds());
        long minutes=TimeUnit.SECONDS.toMinutes(timeConvertir.getSeconds());
        long restSecond=timeConvertir.getSeconds()-TimeUnit.HOURS.toSeconds(hours)- TimeUnit.MINUTES.toSeconds(minutes);
        return String.format("%02d:%02d:%02d",hours,minutes,restSecond);
    }
}
